using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class belt : MonoBehaviour
{
    public float conveyorSpeed = 10.0f;
    public Vector2 direction = new Vector2(0, -1);
    public float alignSpeed = 3.0f;
    public GameObject Initialtarget;
    Vector2 startPos;
    Vector2 targetPos;
    private bool movebox;
    private bool movedown = false;
    private bool moveleft = false;
    private bool stop = false;
    float elapsedTime = 0;
    GameObject box;

    Rigidbody2D boxrb;

    private void Start()
    {
        Initialtarget = GameObject.FindGameObjectWithTag("boxref");
        boxrb = GetComponent<Rigidbody2D>();
        stop = false;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("belt")) {
            Player.boxesInPlace += 1;
            box = this.gameObject;
            startPos = box.transform.position;
            targetPos = Initialtarget.transform.position;// new Vector2(collision.transform.position.x + 0.2f, box.transform.position.y);
            elapsedTime = 0;
            movebox = true;
            stop = false;
        }

        if (collision.CompareTag("stop1"))
        {
            boxrb.constraints = RigidbodyConstraints2D.None;
            movedown = false;
            moveleft = true;
        }
        if (collision.CompareTag("stop2")) { 
            movebox = false;
            moveleft = false;
            movedown = false;
            stop = true;
        }
   
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Box")) {
            movebox = false;
            moveleft = false;
            movedown = false;
            stop = true;
        }
    }

    void Update() {

        if (movebox) {
            if (Vector2.Distance(box.transform.position, targetPos) > 0.1f && Player.holding == false)
            {
                Debug.Log(Vector2.Distance(box.transform.position, targetPos));
                box.transform.position = Vector2.Lerp(startPos, targetPos, elapsedTime * alignSpeed);
                elapsedTime += Time.deltaTime;
            }
            else if (Vector2.Distance(box.transform.position, targetPos) <= 0.15f && Player.holding == false)
            { 
                movebox = false;
                movedown = true;
                Debug.Log("In");
            }
        }
        if (movedown) {
            boxrb.velocity = Vector2.down * elapsedTime * alignSpeed * 5;
        }
        if (moveleft) {
            boxrb.MovePosition(boxrb.position + new Vector2(-10, 0.0f) * Time.deltaTime);
        }
        if(stop){
            boxrb.velocity = Vector2.zero;
        }
    }
}
