using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneMgnt : MonoBehaviour
{
    // Name of the scene to load
    [SerializeField] private string sceneName;

    // This method can be linked to the button's OnClick event
    public void ChangeScene()
    {
        if (!string.IsNullOrEmpty(sceneName))
        {
            SceneManager.LoadScene(sceneName);
        }
        else
        {
            Debug.LogWarning("Scene name is empty. Please assign a valid scene name.");
        }
    }
}