using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI; // For Button interactions

public class TestSim : MonoBehaviour
{
    [System.Serializable]
    public class Question
    {
        public string questionText;
        public string[] options;
        public string explanation;
        public int correctAnswerIndex; // Index of the correct answer in the options array

    }

    // References to TMP UI elements
    public TextMeshProUGUI questionTextTMP;
    public TextMeshProUGUI[] optionButtonsTMP; // Array of TMP buttons for options
    public Button[] optionButtons; // Array of Buttons for detecting clicks

    public GameObject summaryPanel; // Panel to display the summary
    public TextMeshProUGUI summaryTextTMP; // TMP element for displaying the summary text

    public Question[] questions; // Array of questions
    private Question currentQuestion;

    private List<int> unansweredQuestions; // List to track unanswered questions
    private int currentQuestionIndex = 0; // Track the current question index
    private int score = 0; // Track the player's score

    private bool isAnswered = false; // Prevent multiple answers for the same question
    public GameObject respuestas;

    void Start()
    {
        if (questions.Length == 0)
        {
            Debug.LogError("No questions available in the Test Simulator!");
            return;
        }

        // Initialize the unanswered questions list
        unansweredQuestions = new List<int>();
        for (int i = 0; i < questions.Length; i++)
        {
            unansweredQuestions.Add(i);
        }

        LoadNextQuestion();
    }

    void LoadNextQuestion()
    {
        if (unansweredQuestions.Count == 0)
        {
            EndQuiz();
            return;
        }

        // Randomly select a question from unanswered questions
        int randomIndex = Random.Range(0, unansweredQuestions.Count);
        int selectedQuestionIndex = unansweredQuestions[randomIndex];

        // Select the question
        currentQuestion = questions[selectedQuestionIndex];

        // Remove this question from the list of unanswered questions
        unansweredQuestions.RemoveAt(randomIndex);

        // Display the selected question
        DisplayQuestion(currentQuestion);
        isAnswered = false;
    }

    void DisplayQuestion(Question question)
    {
        // Set the question text
        questionTextTMP.text = question.questionText;

        // Enable buttons and set the options text
        for (int i = 0; i < optionButtonsTMP.Length; i++)
        {
            if (i < question.options.Length)
            {
                optionButtonsTMP[i].text = question.options[i];
                optionButtons[i].gameObject.SetActive(true); // Show the button
                optionButtons[i].interactable = true; // Enable button interaction
                int index = i; // Capture the index for the lambda
                optionButtons[i].onClick.RemoveAllListeners(); // Clear previous listeners
                optionButtons[i].onClick.AddListener(() => CheckAnswer(index)); // Add listener for this option
            }
            else
            {
                optionButtons[i].gameObject.SetActive(false); // Hide extra buttons
            }
        }
    }

    void CheckAnswer(int selectedIndex)
    {
        if (isAnswered) return;

        isAnswered = true;

        if (selectedIndex == currentQuestion.correctAnswerIndex)
        {
            Debug.Log("Correct Answer!");
            score++;
        }
        else
        {
            Debug.Log("Wrong Answer!");
        }

        // Disable all buttons to prevent further input
        foreach (var button in optionButtons)
        {
            button.interactable = false;
        }

        // Load the next question after a short delay
        Invoke(nameof(LoadNextQuestion), 2f);
    }

    void EndQuiz()
    {
        questionTextTMP.text = $"Quiz Finished! Your Score: {score}/{questions.Length}";
        respuestas.SetActive(true);
        foreach (var button in optionButtons)
        {
            button.gameObject.SetActive(false); // Hide all buttons
        }
    }

    public void ShowSummary()
    {
        summaryPanel.SetActive(true); 

        string summaryText = "Quiz Summary:\n";
        for (int i = 0; i < questions.Length; i++)
        {
            var question = questions[i];
            summaryText += $"{i + 1}. {question.questionText}\n";
            summaryText += $"Respuesta Correcta: {question.explanation}\n\n";
        }

        summaryTextTMP.text = summaryText; 
    }
}