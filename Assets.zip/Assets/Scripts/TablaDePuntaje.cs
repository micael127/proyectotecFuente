using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TablaDePuntajes : MonoBehaviour
{
    [SerializeField] private Text txtPuntajeFinal;
    [SerializeField] private Text txtNivelFinal;

    void Start()
    {
        MostrarPuntajeFinal();
    }

    private void MostrarPuntajeFinal()
    {
        txtPuntajeFinal.text = "Puntaje Final: " + GameManager.totalPuntos;
        txtNivelFinal.text = "Nivel Alcanzado: " + GameManager.nivelActual;

        GameManager.totalPuntos = 0;
        GameManager.nivelActual = 1;
    }

    public void JugarDeNuevo()
    {
        SceneManager.LoadScene("CASHIER");
    }

    public void VolverAlMenu()
    {
        SceneManager.LoadScene("MENU");
    }
}
