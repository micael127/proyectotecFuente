using UnityEngine;
using UnityEngine.UI;

public class CajaRegistradora : MonoBehaviour
{
    [SerializeField] private Text txtCambioRestante;
    [SerializeField] private Text txtTotal;
    [SerializeField] private Text txtDando;
    [SerializeField] private Text txtPago;
    [SerializeField] private Text txtTiempoTranscurrido;
    [SerializeField] private Text txtPuntosUsuario;

    [SerializeField] private Image clienteCara;
    [SerializeField] private Sprite caraVerde;
    [SerializeField] private Sprite caraAmarilla;
    [SerializeField] private Sprite caraRoja;

    private float precioProducto;
    private float cambioRestante;
    private float dandoCambio;
    private float pagoCliente;

    private float tiempoRestante = 30f;
    private int puntosVenta = 10;

    private GameManager gameManager;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>();
        GenerarTransaccion();
        ActualizarUI();
    }

    public void GenerarTransaccion()
    {
        precioProducto = GenerarPrecio();
        pagoCliente = precioProducto + Random.Range(10f, 50f);
        cambioRestante = Mathf.Round((pagoCliente - precioProducto) * 100) / 100;
        dandoCambio = 0;
        tiempoRestante = 30f;
        ActualizarUI();
    }

    void Update()
    {
        if (tiempoRestante > 0)
        {
            tiempoRestante -= Time.deltaTime;
            if (tiempoRestante <= 0)
            {
                tiempoRestante = 0;
                gameManager.CompletarVenta(AsignarPuntos());
                GenerarTransaccion();
            }
            ActualizarUI();
        }
    }

    public void RecibirDinero(float valorEntregado)
    {
        dandoCambio += valorEntregado;
        cambioRestante -= valorEntregado;
        cambioRestante = Mathf.Max(cambioRestante, 0);

        if (cambioRestante == 0)
        {
            gameManager.CompletarVenta(AsignarPuntos());
            GenerarTransaccion();
        }

        ActualizarUI();
    }

    private int AsignarPuntos()
    {
        if (tiempoRestante > 20f)
        {
            clienteCara.sprite = caraVerde;
            return 10;
        }
        else if (tiempoRestante > 10f)
        {
            clienteCara.sprite = caraAmarilla;
            return 7;
        }
        else
        {
            clienteCara.sprite = caraRoja;
            return 4;
        }
    }

    private void ActualizarUI()
    {
        txtTotal.text = "TOTAL: S/. " + precioProducto.ToString("F2");
        txtPago.text = "PAGO: S/. " + pagoCliente.ToString("F2");
        txtCambioRestante.text = "CAMBIO: S/. " + cambioRestante.ToString("F2");
        txtDando.text = "DANDO: S/. " + dandoCambio.ToString("F2");
        txtTiempoTranscurrido.text = "Tiempo: " + tiempoRestante.ToString("F2") ;
        txtPuntosUsuario.text = "Puntos: " + GameManager.totalPuntos.ToString("F2");
    }

    private float GenerarPrecio()
    {
        return Mathf.Round(Random.Range(10f, 100f) / 10) * 10;
    }
}
