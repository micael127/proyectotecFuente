using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] private CajaRegistradora cajaRegistradora;
    [SerializeField] private float tiempoLimite = 60f;
    [SerializeField] private int ventasParaGanar = 5;

    public static int totalPuntos = 0;
    public static int nivelActual = 1;

    private bool juegoActivo = true;

    void Start()
    {
        StartCoroutine(IniciarJuego());
    }

    IEnumerator IniciarJuego()
    {
        while (juegoActivo)
        {
            yield return new WaitForSeconds(1f);
            tiempoLimite -= 1f;

            if (tiempoLimite <= 0)
            {
                tiempoLimite = 0;
                TerminarJuego();
            }
        }
    }

    public void CompletarVenta(int puntosVenta)
    {
        totalPuntos += puntosVenta;

        if (--ventasParaGanar <= 0)
        {
            TerminarJuego();
        }
    }

    void TerminarJuego()
    {
        juegoActivo = false;
        SceneManager.LoadScene("TablaDePuntajes");
    }
}
