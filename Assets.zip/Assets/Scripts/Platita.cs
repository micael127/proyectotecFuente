using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Platita : MonoBehaviour
{
    [SerializeField] private float valor;
    [SerializeField] private int cantidad = 10;
    [SerializeField] private Text cantidadTxt;

    private CajaRegistradora cajaRegistradora;

    void Start()
    {
        cajaRegistradora = FindObjectOfType<CajaRegistradora>();
        ActualizarTexto();
    }

    void OnMouseDown()
    {
        if (cantidad > 0)
        {
            cantidad--;
            cajaRegistradora.RecibirDinero(valor);
            ActualizarTexto();

            if (cantidad <= 0)
            {
                gameObject.SetActive(false);
            }
        }
    }

    void ActualizarTexto()
    {
        cantidadTxt.text = cantidad.ToString();
    }
}
