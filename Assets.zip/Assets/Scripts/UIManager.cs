using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    [SerializeField] private Text txtTiempoTranscurrido;
    [SerializeField] private Text txtTotal;
    [SerializeField] private Text txtCambioRestante;
    [SerializeField] private Text txtPago;
    [SerializeField] private Text txtDando;
    [SerializeField] private Text txtPuntosUsuario;
    [SerializeField] private GameObject panelInicio;
    [SerializeField] private GameObject panelFinal;
    [SerializeField] private Text txtMensajeFinal;
    [SerializeField] private Text txtNivel;

    public void ActualizarTiempo(float tiempo)
    {
        txtTiempoTranscurrido.text = "Tiempo: " + tiempo.ToString("F2") + " s";
    }

    public void MostrarPanelInicio(string mensaje, System.Action callback)
    {
        panelInicio.SetActive(true);
        txtNivel.text = mensaje;
        Button botonInicio = panelInicio.GetComponentInChildren<Button>();
        botonInicio.onClick.AddListener(() =>
        {
            panelInicio.SetActive(false);
            callback?.Invoke();
        });
    }

    public void MostrarPanelFinal(string mensaje, System.Action callback)
    {
        panelFinal.SetActive(true);
        txtMensajeFinal.text = mensaje;
        Button botonFinal = panelFinal.GetComponentInChildren<Button>();
        botonFinal.onClick.AddListener(() =>
        {
            panelFinal.SetActive(false);
            callback?.Invoke();
        });
    }

    public void ActualizarNivel(int nivel)
    {
        txtNivel.text = "Nivel " + nivel;
    }

    public void ActualizarTransaccion(float precioProducto, float cambioRestante, float dandoCambio, float pagoCliente, int totalPuntos)
    {
        txtTotal.text = "TOTAL: S/. " + precioProducto.ToString("F2");
        txtCambioRestante.text = "CAMBIO: S/. " + cambioRestante.ToString("F2");
        txtPago.text = "Pago: S/. " + pagoCliente.ToString("F2");
        txtDando.text = "DANDO: S/. " + dandoCambio.ToString("F2");
        txtPuntosUsuario.text = "Puntos: " + totalPuntos;
    }
}
