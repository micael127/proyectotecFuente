using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RFIDCanvas : MonoBehaviour
{
    public GameObject box;
    private float x = 200;
    private float y = 250;
    static public int boxes;
    private int i = 0;
    static public int tag = 0;
    private Canvas _canvas;
    // private RectTransform rectTransform;

    void OnEnable() {
        GameObject canvas = GameObject.FindGameObjectWithTag("CameraCanvas");
        _canvas = canvas.GetComponent<Canvas>();
        x = x * _canvas.scaleFactor;
        y = y * _canvas.scaleFactor;

        boxes = truck.Initboxes;
        Debug.Log(boxes);
        i = Mathf.CeilToInt((((float)boxes) / 4.0f));
        int remaining = 4;
        for (int j = 0; j < i; j++)
        {
            for (int k = 0; k < remaining; k++)
            {
                GameObject b = Instantiate(box, this.transform);
                RectTransform rectTransform = b.GetComponent<RectTransform>();
                rectTransform.position = new Vector3(x, y);
                x += 110 * _canvas.scaleFactor; ;

            }
            y -= 100 * _canvas.scaleFactor;
            x = 200 * _canvas.scaleFactor;
            remaining = boxes - 4;
        }
    }

}
