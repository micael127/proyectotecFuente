using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public float speed;

    private Rigidbody2D rb;
    private Animator animator;

    private float horizontal;
    private float vertical;
    private bool isFacingRight = true;

    public Transform holdPosition;  // The position where the box will be held
    public float pickupRange = 1.5f; // Range within which the player can pick up the box
    private GameObject heldObject;   // The object the player is holding
    public GameObject box;
    private GameObject[] targets;
    public static bool holding = false;
    public static int boxesInPlace = 0;

    void Start(){
        rb = GetComponent<Rigidbody2D>();   
        animator = GetComponent<Animator>();
        targets = GameObject.FindGameObjectsWithTag("trucks");
    }

    void Update(){
        horizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");
        animator.SetFloat("walk",Mathf.Abs(horizontal) + Mathf.Abs(vertical));
        
        // Flip the character based on direction
        if (horizontal > 0 && !isFacingRight && heldObject == null){
           Flip();
        }
        else if (horizontal < 0 && isFacingRight && heldObject == null){
            Flip();
        }

        if (horizontal > 0 && heldObject != null){
            animator.SetBool("push", true);
            animator.SetBool("pull", false);
        }
        else if (horizontal < 0 && heldObject != null){
            animator.SetBool("push", false);
            animator.SetBool("pull", true);
        }


        MoveBoxes();

        foreach (GameObject target in targets)
        {
            if (target != null)
            {
                float distance = Vector3.Distance(this.transform.position, target.transform.position);
                // truck targetTruck = target.GetComponent<truck>();
                if (distance < 3.5f && truck.boxes > 0) {
                    if (Input.GetKeyDown(KeyCode.E)) { 
                        GameObject b = Instantiate(box, holdPosition.position,Quaternion.identity);
                        Rigidbody2D rigidbody2D = b.GetComponent<Rigidbody2D>();
                        StartCoroutine(ApplyKinematicVelocity(rigidbody2D));
                        truck.boxes -= 1;
                    }
                }
            }
        }

    }

    IEnumerator ApplyKinematicVelocity(Rigidbody2D rb)
    {
        float duration = 0.15f; // Duration of the movement
        float elapsedTime = 0f;

        while (elapsedTime < duration)
        {
            rb.MovePosition(rb.position + new Vector2(0,-10.0f) * Time.deltaTime);
            elapsedTime += Time.deltaTime;
            yield return null;
        }
    }

    void FixedUpdate(){
        Vector2 move = new Vector2(horizontal, vertical);
        move.Normalize();
        rb.velocity = move * speed * Time.deltaTime;
    }

    void Flip()
    {
        // Flip the character by inverting its local scale on the X axis
        isFacingRight = !isFacingRight;
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }

    void PickupObject(GameObject obj)
    {
        heldObject = obj;
        Rigidbody2D heldRb = heldObject.GetComponent<Rigidbody2D>();
        heldRb.isKinematic = true; // Disable physics while holding
        heldObject.transform.position = holdPosition.position;
        heldObject.transform.SetParent(transform);
        holding = true;
    }

    void MoveBoxes() {
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (heldObject == null)
            {
                // Try to pick up a box
                Collider2D[] objectsInRange = Physics2D.OverlapCircleAll(transform.position, pickupRange);
                foreach (Collider2D col in objectsInRange)
                {
                    if (col.CompareTag("Box"))
                    {
                        PickupObject(col.gameObject);
                        break;
                    }
                }
            }
            else
            {
                // Drop the box if already holding one
                DropObject();
                animator.SetBool("push", false);
                animator.SetBool("pull", false);
            }
        }
    }

    void DropObject()
    {
        Rigidbody2D heldRb = heldObject.GetComponent<Rigidbody2D>();
        heldObject.transform.SetParent(null); // Unparent the object

        // Reset physics to make the box stay in place
        // heldRb.isKinematic = false; // Re-enable physics
        heldRb.velocity = Vector2.zero; // Stop any motion
        heldRb.angularVelocity = 0f; // Stop any rotation
        heldRb.constraints =  RigidbodyConstraints2D.FreezeRotation;
        heldRb.isKinematic = false;

        heldObject = null;
        holding = false;
    }

    // Draws the pickup range for debugging purposes in the editor
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, pickupRange);
    }
}
