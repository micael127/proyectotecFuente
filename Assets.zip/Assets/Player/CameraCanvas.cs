using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using TMPro;

public class CameraCanvas : MonoBehaviour
{
    public GameObject tag;
    private float x = 100;
    private float y = 140;
    static public int boxes;
    private int i = 0;
    static public int tagNum = 0;

    public Transform current;

    public void printRFIDTag(){
        if (tagNum < Guide.box_check) { 
            GameObject t = Instantiate(tag, current.transform);
            RectTransform rectTransform = t.GetComponent<RectTransform>();
            rectTransform.position = new Vector3(x, y);
            foreach (Transform child in rectTransform){
                TMP_Text tmpComponent = child.GetComponent<TMP_Text>();
                if (tmpComponent != null)
                    tmpComponent.text = GenerateRandomLetters(6);
            }
            tagNum++;
        }
    }

    string GenerateRandomLetters(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.Text.StringBuilder result = new System.Text.StringBuilder(length);
        System.Random random = new System.Random();

        for (int i = 0; i < length; i++)
        {
            result.Append(chars[random.Next(chars.Length)]);
        }

        return result.ToString();
    }

}
