using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Device : MonoBehaviour
{
    private Animator anim;

    public GameObject button_act;

    private void Start()
    {
        anim = GetComponent<Animator>();
    }


    void OnMouseDown()
    {
        if (Guide.boxesDone == 1)
        {
            Debug.Log($"You clicked on: {gameObject.name}");
            button_act.SetActive(true);
            RFIDCanvas.boxes = truck.Initboxes;
            anim.SetBool("click", false);
        }


    }

}
