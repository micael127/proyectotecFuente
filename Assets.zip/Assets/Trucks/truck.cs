using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class truck : MonoBehaviour
{
    public float speed;
    private Rigidbody2D rb;
    private int direction;
    public TMP_Text text;
    static public int boxes = 0;
    static public int Initboxes = 0;

    void Start(){
        boxes = Random.Range(4, 7);
        Initboxes = boxes;
        Guide.box_check = boxes;
        rb = GetComponent<Rigidbody2D>();
        direction = 1;
        text.text = boxes.ToString();
        Debug.Log(Initboxes);
    }
    
    // Update is called once per frame
    void FixedUpdate(){
        text.text = boxes.ToString();
        rb.velocity = Vector2.left * speed * direction * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.gameObject.CompareTag("truckbound")) {
            direction *= 0; 
        }
    }
}
