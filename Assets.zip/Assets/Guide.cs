using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class Guide : MonoBehaviour
{
    public TMP_Text tmpObject; // Drag and drop your TMP text object here in the Inspector
    // public string newText = "Hello, World!"; // The text you want to change to
    public float delayInSeconds = 10.0f; // Delay before the text changes
    static public int box_check = 0;
    public static int boxesDone, UnloadingDone, TagsDone = 0;
    public Animator animatorMachine;
    public GameObject doneButton;
    void FixedUpdate()
    {
        if (UnloadingDone == 0)
        {
            if (truck.boxes == 0)
            {
                tmpObject.color = new Color(0.2f, 0.9f, 0.2f);
                StartCoroutine(ChangeTextAfterDelay("Lleva las cajas al �rea A"));
                UnloadingDone = 1;
            }
        }

        if (boxesDone == 0) {
            if (Player.boxesInPlace == box_check) {
                tmpObject.color = new Color(0.2f, 0.9f, 0.2f);
                StartCoroutine(ChangeTextAfterDelay("A�adir las etiquetas RFID (Click para interactuar)"));
                boxesDone = 1;
                animatorMachine.SetBool("click",true);
            }
        }
        if (TagsDone == 0)
        {
            if (!(CameraCanvas.tagNum < box_check))
            {
                tmpObject.color = new Color(0.2f, 0.9f, 0.2f);
                doneButton.SetActive(true);
                StartCoroutine(ChangeTextAfterDelay("Terminaste, �muy bien!"));
                TagsDone = 1;
            }
        }
    }

    private IEnumerator ChangeTextAfterDelay(string newText)
    {
        // Wait for the specified delay
        yield return new WaitForSeconds(delayInSeconds);
        // Change the text
        if (tmpObject != null)
        {
            tmpObject.text = newText;
            tmpObject.color = new Color(0, 0, 0);
        }
        else
        {
            Debug.LogError("TMP_Text object is not assigned!");
        }
    }



}
